# Spring WebFlux base application integrated with Spring Security running on Spring Boot and connecting to Mongo DB
<img src="../screenshots/4.1.png" alt="" align="center">  
  
<img src="../screenshots/4.2.png" alt="" align="center">  

<img src="../screenshots/4.3.png" alt="" align="center">  

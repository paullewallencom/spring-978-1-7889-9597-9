# Spring WebFlux base application running on Spring Boot using Tomcat as the server
<img src="../screenshots/6.1.png" alt="" align="center">  
  
<img src="../screenshots/6.2.png" alt="" align="center">  

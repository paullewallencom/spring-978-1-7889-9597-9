package com.packtpub.book.ch05.springsecurity.exception;

public class SampleException extends Exception{

	private static final long serialVersionUID = 1L;
}

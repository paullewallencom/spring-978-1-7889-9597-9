# Spring WebFlux base application integrated with Spring Security running on Spring Boot showing off WebClient
<img src="../screenshots/3.1.png" alt="" align="center">  
  
<img src="../screenshots/3.2.png" alt="" align="center">  

<img src="../screenshots/3.3.png" alt="" align="center">  

<img src="../screenshots/3.4.png" alt="" align="center">  



# Spring WebFlux base application running on Spring Boot and showing off some customizations possible
<img src="../screenshots/5.1.png" alt="" align="center">  
  
<img src="../screenshots/5.2.png" alt="" align="center">  

<img src="../screenshots/5.3.png" alt="" align="center">  

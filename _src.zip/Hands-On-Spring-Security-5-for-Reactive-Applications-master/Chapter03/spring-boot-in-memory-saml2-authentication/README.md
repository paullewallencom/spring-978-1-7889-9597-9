# SAML based Authentication using in-memory store and running on Spring Boot
<img src="../screenshots/1.1.png" alt="" align="center">  
  
<img src="../screenshots/1.2.png" alt="" align="center">  

<img src="../screenshots/1.3.png" alt="" align="center">  
  
<img src="../screenshots/1.4.png" alt="" align="center">  

<img src="../screenshots/1.5.png" alt="" align="center">  

<img src="../screenshots/1.6.png" alt="" align="center">  

<img src="../screenshots/1.7.png" alt="" align="center">  

<img src="../screenshots/1.8.png" alt="" align="center">  

<img src="../screenshots/1.9.png" alt="" align="center">  

<img src="../screenshots/1.10.png" alt="" align="center">  

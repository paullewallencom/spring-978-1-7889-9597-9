# Running on Spring Boot, authenticating using LDAP as store using Basic authentication
<img src="../screenshots/2.1.png" alt="" align="center">  
  
<img src="../screenshots/2.2.png" alt="" align="center">  

<img src="../screenshots/2.3.png" alt="" align="center">  
  
<img src="../screenshots/2.4.png" alt="" align="center">  

<img src="../screenshots/2.5.png" alt="" align="center">  

<img src="../screenshots/2.6.png" alt="" align="center">  

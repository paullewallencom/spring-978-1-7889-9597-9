# Basic Authentication using database and running on Jetty Server
<img src="../screenshots/1.1.png" alt="" align="center">  
  
<img src="../screenshots/1.2.png" alt="" align="center">  

<img src="../screenshots/1.3.png" alt="" align="center">  
  
<img src="../screenshots/1.4.png" alt="" align="center">  

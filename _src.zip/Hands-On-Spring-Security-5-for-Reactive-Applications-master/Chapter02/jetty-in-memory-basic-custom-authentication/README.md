# Basic Authentication using in-memory user store having custom authentication and running on Jetty Server
<img src="../screenshots/4.1.png" alt="" align="center">  
  
<img src="../screenshots/4.2.png" alt="" align="center">  

<img src="../screenshots/4.3.png" alt="" align="center">  
  
<img src="../screenshots/4.4.png" alt="" align="center">  

# Basic Authentication using in-memory user store and running on Jetty Server
<img src="../screenshots/2.1.png" alt="" align="center">  
  
<img src="../screenshots/2.2.png" alt="" align="center">  

<img src="../screenshots/2.3.png" alt="" align="center">  
  
<img src="../screenshots/2.4.png" alt="" align="center">  

package com.packtpub.book.ch02.springsecurity.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {

}
